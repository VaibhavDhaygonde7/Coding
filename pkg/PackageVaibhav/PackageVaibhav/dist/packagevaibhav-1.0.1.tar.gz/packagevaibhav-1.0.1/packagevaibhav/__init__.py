def function1(number):
    print("This is a function1")
    return number