from setuptools import setup
setup(name="packagevaibhav",
      version="1.0.1",
      description="This is the first package made by me", 
      long_description="This is the first package made by me and it is a simple function which simply returns the number",
      author = "Vaibhav", 
      packages=['packagevaibhav'],
      install_requires = [])
